import os
from pathlib import Path

import streamlit as st

BASE_DIR = Path(__file__).resolve().parent

st.set_page_config(
    page_title="SkillMatch AI",
    page_icon=str(BASE_DIR / "assets" / "logo.svg"),
    layout="wide",
)

st.session_state.setdefault("authenticated", False)
st.session_state.setdefault("curriculum_text", "")
st.session_state.setdefault("curriculum_name", "")
st.session_state.setdefault("industry_text", "")
st.session_state.setdefault("industry_name", "")
st.session_state.setdefault("industry_role", "")
st.session_state.setdefault("industry_domain", "")
st.session_state.setdefault("analysis_report", None)
st.session_state.setdefault("analysis_history", [])
st.session_state.setdefault("rag_sources", [])
st.session_state.setdefault("rag_answer", "")
st.session_state.setdefault("theme_mode", "Dark")

with st.sidebar:
    st.markdown("### Appearance")
    st.radio(
        "Color mode",
        ["Dark", "Light"],
        horizontal=True,
        key="theme_mode",
        label_visibility="collapsed",
    )

with (BASE_DIR / "assets" / "style.css").open(encoding="utf-8") as css_file:
    css = css_file.read()

if st.session_state.theme_mode == "Light":
    theme_overrides = """
    :root, [data-testid="stAppViewContainer"] {
      --background-color: #e9f8f2;
      --secondary-background-color: #f7fffc;
      --text-color: #16352f;
      --primary-color: #16866f;
      --border-color: #bddfd4;
      --widget-background-color: #fafffd;
      --muted-color: #52766d;
      --sidebar-background: #d9f1e7;
      --card-top: rgba(61, 179, 151, .20);
      --card-bottom: rgba(15, 145, 131, .08);
      --button-start: #20a17d;
      --button-end: #087f89;
    }
    """
else:
    theme_overrides = """
    :root, [data-testid="stAppViewContainer"] {
      --background-color: #071f20;
      --secondary-background-color: #0d3433;
      --text-color: #effcf8;
      --primary-color: #42cdb1;
      --border-color: #22534d;
      --widget-background-color: #103c3a;
      --muted-color: #a9cfc4;
      --sidebar-background: #092927;
      --card-top: rgba(55, 211, 177, .22);
      --card-bottom: rgba(24, 137, 153, .12);
      --button-start: #30a98d;
      --button-end: #087f91;
    }
    """

st.html(f"<style>{css}\n{theme_overrides}</style>")

try:
    from dotenv import load_dotenv
    load_dotenv(BASE_DIR / ".env")
except Exception:
    pass

if not st.session_state.authenticated:
    welcome = st.Page("app_pages/welcome.py", title="Welcome", icon=":material/waving_hand:")
    page = st.navigation([welcome], position="top")
else:
    pages = {
        "Workspace": [
            st.Page("app_pages/dashboard.py", title="Dashboard", icon=":material/dashboard:", default=True),
            st.Page("app_pages/curriculum_upload.py", title="Curriculum", icon=":material/menu_book:"),
            st.Page("app_pages/industry_requirements.py", title="Industry requirements", icon=":material/work:"),
        ],
        "Intelligence": [
            st.Page("app_pages/skill_analysis.py", title="Skill gap analysis", icon=":material/compare_arrows:"),
            st.Page("app_pages/recommendations.py", title="Recommendations", icon=":material/auto_awesome:"),
            st.Page("app_pages/reports.py", title="Reports", icon=":material/summarize:"),
        ],
    }
    page = st.navigation(pages, position="sidebar")

page.run()
