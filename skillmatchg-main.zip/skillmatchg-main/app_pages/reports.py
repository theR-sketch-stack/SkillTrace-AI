import datetime

import streamlit as st

from utils.report_generator import build_pdf, build_excel, build_csv

st.markdown("## Reports")
st.caption("Download the latest structured SkillMatch AI analysis.")

report = st.session_state.analysis_report
if not report:
    st.info("Complete an analysis to generate downloadable reports.")
else:
    m1, m2, m3 = st.columns(3)
    m1.metric("Alignment score", f"{report['gap']['alignment_score']:.1f}%")
    m2.metric("Recommendations", len(report["recommendations"]))
    m3.metric("Generated", report["analysis_date"])

    with st.container(border=True):
        st.markdown("### Report contents")
        st.write(
            "- Project title and analysis date\n"
            "- Curriculum and industry source names\n"
            "- Matched, missing and partially covered skills\n"
            "- Outdated topic flags and emerging skills\n"
            "- Transparent alignment score\n"
            "- Evidence-based curriculum recommendations"
        )

    st.write("")
    pdf_col, excel_col, csv_col = st.columns(3)
    with pdf_col:
        st.download_button(
            "Download PDF",
            data=build_pdf(report),
            file_name="skillmatch_report.pdf",
            mime="application/pdf",
            width="stretch",
        )
    with excel_col:
        st.download_button(
            "Download Excel",
            data=build_excel(report),
            file_name="skillmatch_report.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            width="stretch",
        )
    with csv_col:
        st.download_button(
            "Download CSV",
            data=build_csv(report),
            file_name="skillmatch_report.csv",
            mime="text/csv",
            width="stretch",
        )
