import pandas as pd
import streamlit as st

from utils.helpers import load_uploaded_text
from core.skill_extractor import extract_skills, extract_subjects

if st.session_state.curriculum_name == "Sample CSE Curriculum (Demonstration)":
    st.session_state.curriculum_text = ""
    st.session_state.curriculum_name = ""
    st.session_state.analysis_report = None
    st.session_state.rag_sources = []
    st.session_state.rag_answer = ""
    st.session_state.pop("curriculum_review", None)

st.markdown("## Curriculum upload")
st.caption("Upload or review syllabus content for curriculum-side evidence.")

tabs = st.tabs(["Upload", "Review"])
with tabs[0]:
    uploaded = st.file_uploader("Drop a curriculum document",
                                type=["pdf", "docx", "txt"],
                                key="curriculum_uploader")
    if uploaded:
        try:
            text = load_uploaded_text(uploaded)
            if not text.strip():
                st.warning("No readable text was found in this document.")
            else:
                st.session_state.curriculum_text = text
                st.session_state.curriculum_name = uploaded.name
                st.success(f"{uploaded.name} loaded successfully.")
        except Exception as exc:
            st.error(str(exc))

with tabs[1]:
    text = st.session_state.curriculum_text
    if text:
        st.text_area("Extracted curriculum text", value=text, height=260,
                     key="curriculum_review")
        skills = extract_skills(text)
        subjects = extract_subjects(text)
        c1, c2 = st.columns(2)
        with c1:
            st.markdown("### Identified subjects")
            st.write(", ".join(subjects) if subjects else "No subjects identified.")
        with c2:
            st.markdown("### Identified skills")
            st.write(", ".join(skills) if skills else "No known skills identified.")
        st.dataframe(pd.DataFrame({"Skills": skills}), width="stretch", hide_index=True)
    else:
        st.info("No curriculum content has been loaded.")
