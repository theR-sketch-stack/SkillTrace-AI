import pandas as pd
import streamlit as st

st.markdown("## Curriculum recommendations")
st.caption("Actionable improvements derived only from the latest gap result.")

report = st.session_state.analysis_report
if not report:
    st.info("Run an AI skill gap analysis before generating recommendations.")
else:
    recommendations = report["recommendations"]
    if recommendations:
        for recommendation in recommendations:
            priority = recommendation["priority"]
            with st.container(border=True):
                h1, h2 = st.columns([3, 1])
                with h1:
                    st.markdown(f"### {recommendation['topic']}")
                with h2:
                    st.markdown(
                        f'<span class="status-chip">{recommendation["status"]} · {priority}</span>',
                        unsafe_allow_html=True,
                    )
                st.write(f"**Why it is required:** {recommendation['why']}")
                st.write(f"**Suggested learning outcome:** {recommendation['learning_outcome']}")
                st.caption(f"Supporting evidence: {recommendation['source']}")
            st.write("")

        st.download_button(
            "Download recommendation CSV",
            pd.DataFrame(recommendations).to_csv(index=False).encode("utf-8"),
            file_name="skillmatch_recommendations.csv",
            mime="text/csv",
        )
    else:
        st.success("No recommendations are needed based on the current evidence.")
