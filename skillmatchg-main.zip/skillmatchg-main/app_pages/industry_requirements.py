from pathlib import Path

import streamlit as st

from core.skill_extractor import extract_skills
from utils.helpers import load_uploaded_text

st.markdown("## Industry requirements")
st.caption("Upload a job description or paste requirements directly.")

st.session_state.industry_role = st.text_input(
    "Job role", value=st.session_state.industry_role,
    placeholder="Example: Python Developer"
)
st.session_state.industry_domain = st.selectbox(
    "Industry domain",
    ["Software Engineering", "Data Analytics", "Artificial Intelligence",
     "Cloud Computing", "Cybersecurity", "Enterprise IT"],
    index=0,
)

upload_tab, paste_tab, sample_tab = st.tabs(["Upload", "Paste text", "Sample jobs"])
with upload_tab:
    uploaded = st.file_uploader("Drop a job description",
                                type=["pdf", "docx", "txt"],
                                key="industry_uploader")
    if uploaded:
        try:
            text = load_uploaded_text(uploaded)
            if text.strip():
                st.session_state.industry_text = text
                st.session_state.industry_name = uploaded.name
                st.success(f"{uploaded.name} loaded successfully.")
            else:
                st.warning("No readable text was found.")
        except Exception as exc:
            st.error(str(exc))

with paste_tab:
    pasted = st.text_area("Job description", height=260,
                          value=st.session_state.industry_text,
                          placeholder="Paste required skills, responsibilities and experience...")
    name = st.text_input("Description name", value=st.session_state.industry_name or "Pasted job description")
    if st.button("Save job description", width="stretch"):
        if pasted.strip():
            st.session_state.industry_text = pasted
            st.session_state.industry_name = name
            st.success("Industry description saved.")
        else:
            st.warning("Enter a job description first.")

with sample_tab:
    sample_dir = Path("data/sample_jobs")
    samples = {path.stem.replace("_", " ").title(): path
               for path in sorted(sample_dir.glob("*.txt"))}
    selected = st.selectbox("Demonstration job description", list(samples))
    if st.button("Load selected sample", width="stretch"):
        text = samples[selected].read_text(encoding="utf-8")
        st.session_state.industry_text = text
        st.session_state.industry_name = f"{selected} (Demonstration)"
        st.success(f"{selected} sample loaded.")

text = st.session_state.industry_text
if text:
    st.markdown("### Extracted evidence")
    skills = extract_skills(text)
    c1, c2 = st.columns([1, 2])
    with c1:
        st.write("**Required skills**")
        st.write(", ".join(skills) if skills else "No known skills identified.")
    with c2:
        st.text_area("Industry requirement text", value=text, height=180,
                     key="industry_review")
