import streamlit as st

_TEXT_ONLY_INPUT = st.components.v2.component(
    "skillmatch_text_only_input",
    html="""
    <label for="text-input" id="text-input-label"></label>
    <input id="text-input" type="text" autocomplete="off" />
    """,
    css="""
    label {
      display: block;
      margin-bottom: 0.4rem;
      color: var(--text-color, var(--st-text-color));
      font-size: 0.875rem;
    }
    input {
      box-sizing: border-box;
      width: 100%;
      padding: 0.6rem 0.75rem;
      border: 1px solid var(--border-color, var(--st-border-color));
      border-radius: 0.5rem;
      background: var(--widget-background-color, var(--st-secondary-background-color));
      color: var(--text-color, var(--st-text-color));
      font: inherit;
    }
    input:focus {
      outline: 2px solid var(--primary-color, var(--st-primary-color));
      outline-offset: 1px;
    }
    """,
    js="""
    export default function (component) {
      const { data, parentElement, setStateValue } = component;
      const label = parentElement.querySelector("#text-input-label");
      const input = parentElement.querySelector("#text-input");
      if (!label || !input) return;

      label.textContent = data.label;
      input.setAttribute("aria-label", data.label);
      const nextValue = data.value ?? "";
      if (input.value !== nextValue) input.value = nextValue;

      const updateValue = () => {
        const cursor = input.selectionStart ?? input.value.length;
        const value = input.value.replace(/[0-9]/g, "");
        if (input.value !== value) {
          const nextCursor = input.value.slice(0, cursor).replace(/[0-9]/g, "").length;
          input.value = value;
          input.setSelectionRange(nextCursor, nextCursor);
        }
        setStateValue("value", value);
      };

      input.onkeydown = (event) => {
        if (/^[0-9]$/.test(event.key)) event.preventDefault();
      };
      input.oninput = updateValue;
      input.onpaste = (event) => {
        const pasted = event.clipboardData?.getData("text") ?? "";
        if (!/[0-9]/.test(pasted)) return;
        event.preventDefault();
        const start = input.selectionStart ?? input.value.length;
        const end = input.selectionEnd ?? start;
        input.setRangeText(pasted.replace(/[0-9]/g, ""), start, end, "end");
        updateValue();
      };
    }
    """,
)


def text_only_input(label, key):
    component_state = st.session_state.get(key, {})
    value = component_state.get("value", "")
    _TEXT_ONLY_INPUT(
        key=key,
        data={"label": label, "value": value},
    )
    return value


left, right = st.columns([1.1, .9], gap="large")
with left:
    st.markdown(
        '<div class="hero-card">'
        '<div class="status-chip">AI Curriculum Intelligence</div>'
        '<div class="brand-name" style="margin-top:1.1rem;">SkillMatch <span class="accent-text">AI</span></div>'
        '<div class="tagline">Bridging Academic Learning with Industry Demands.</div>'
        '<p style="margin-top:1.4rem; max-width:560px; color:#aeb8d4;">'
        'Analyze syllabus documents, retrieve evidence, compare curriculum coverage with industry '
        'requirements, and produce a transparent, data-grounded improvement roadmap.</p>'
        '</div>',
        unsafe_allow_html=True,
    )
with right:
    with st.container(border=True):
        st.markdown("### Demonstration sign in")
        st.caption("Simple local demo login. No credentials are stored.")
        name = text_only_input("Name", "sign_in_name")
        institution = text_only_input("Institution", "sign_in_institution")
        if st.button("Get started", width="stretch"):
            if not name.strip() or not institution.strip():
                st.error("Enter your name and institution to continue.")
            elif any(character.isdigit() for character in name + institution):
                st.error("Numbers are not allowed in the name or institution.")
            else:
                st.session_state.authenticated = True
                st.session_state.user_name = name
                st.session_state.institution = institution
                st.rerun()
