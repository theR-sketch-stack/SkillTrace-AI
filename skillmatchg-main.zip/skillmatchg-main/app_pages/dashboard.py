import pandas as pd
import plotly.express as px
import streamlit as st

report = st.session_state.get("analysis_report")
gap = report["gap"] if report else None

st.markdown("## Dashboard")
st.caption("Curriculum-to-industry alignment overview")

curriculum_count = 1 if st.session_state.curriculum_text else 0
industry_count = 1 if st.session_state.industry_text else 0
skill_count = len(set(
    (gap["academic_skills"] if gap else []) +
    (gap["industry_skills"] if gap else [])
))
alignment = gap["alignment_score"] if gap else 0.0
missing_count = len(gap["missing"]) if gap else 0
outdated_count = len(gap["outdated"]) if gap else 0
chart_template = (
    "plotly_white"
    if st.session_state.get("theme_mode") == "Light"
    else "plotly_dark"
)
chart_font = (
    "#18233b"
    if st.session_state.get("theme_mode") == "Light"
    else "#e8edfa"
)

cards = [
    (curriculum_count, "Curriculum documents"),
    (industry_count, "Job descriptions"),
    (skill_count, "Identified skills"),
    (f"{alignment:.1f}%", "Overall alignment"),
]
cols = st.columns(4)
for col, (value, label) in zip(cols, cards):
    with col:
        st.markdown(
            f'<div class="metric-card"><div class="value">{value}</div>'
            f'<div class="label">{label}</div></div>',
            unsafe_allow_html=True,
        )

st.write("")
if gap:
    chart_col, summary_col = st.columns([2, 1], gap="large")
    with chart_col:
        with st.container(border=True):
            st.markdown("### Academic vs industry skills")
            comparison = pd.DataFrame([
                {"Type": "Academic", "Count": len(gap["academic_skills"])},
                {"Type": "Industry", "Count": len(gap["industry_skills"])},
            ])
            fig = px.bar(
                comparison,
                x="Type",
                y="Count",
                color="Type",
                color_discrete_map={"Academic": "#3D7EFF", "Industry": "#8B5CF6"},
                text="Count",
                template=chart_template,
            )
            fig.update_layout(
                height=300,
                showlegend=False,
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                font_color=chart_font,
            )
            st.plotly_chart(fig, width="stretch")
    with summary_col:
        with st.container(border=True):
            st.markdown("### Gap summary")
            summary = pd.DataFrame([
                {"Status": "Matched", "Count": len(gap["matched"])},
                {"Status": "Missing", "Count": missing_count},
                {"Status": "Partial", "Count": len(gap["partial"])},
                {"Status": "Outdated", "Count": outdated_count},
            ])
            fig2 = px.pie(
                summary,
                names="Status",
                values="Count",
                hole=.68,
                color_discrete_sequence=["#35C9A8", "#FF6378", "#F6C85F", "#8B5CF6"],
                template=chart_template,
            )
            fig2.update_layout(
                height=300,
                paper_bgcolor="rgba(0,0,0,0)",
                showlegend=True,
                font_color=chart_font,
            )
            st.plotly_chart(fig2, width="stretch")

    demand_col, history_col = st.columns([1.4, 1], gap="large")
    with demand_col:
        with st.container(border=True):
            st.markdown("### Top industry skills")
            top_skills = gap["industry_skills"][:10]
            demand = pd.DataFrame({
                "Skill": top_skills,
                "Demand": [1] * len(top_skills),
            })
            fig3 = px.bar(
                demand,
                y="Skill",
                x="Demand",
                orientation="h",
                template=chart_template,
                text="Skill",
            )
            fig3.update_layout(
                height=330,
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                showlegend=False,
                font_color=chart_font,
                xaxis={"visible": False},
                yaxis={"categoryorder": "total ascending"},
            )
            st.plotly_chart(fig3, width="stretch")
    with history_col:
        with st.container(border=True):
            st.markdown("### Recent analysis")
            history = st.session_state.analysis_history
            if history:
                st.dataframe(
                    pd.DataFrame(history[-5:]),
                    width="stretch",
                    hide_index=True,
                )
            else:
                st.caption("Run an analysis to add history.")
else:
    st.info("Load curriculum and industry documents, then run the skill gap analysis.")
