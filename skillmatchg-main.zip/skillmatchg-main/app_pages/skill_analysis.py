import datetime
import os

import pandas as pd
import streamlit as st

from agents.orchestrator import AnalysisOrchestrator
from config.settings import VECTOR_DIR
from rag.document_loader import build_documents
from rag.vector_store import VectorStore
from rag.retriever import Retriever
from rag.rag_pipeline import RAGPipeline

st.markdown("## AI skill gap analysis")
st.caption("Evidence-grounded comparison using skill matching and RAG.")

if os.getenv("NEXUS_API_KEY"):
    provider_name = "Nexus"
    selected_model = os.getenv("NEXUS_MODEL", "gpt-4.1-nano")
elif os.getenv("GEMINI_API_KEY"):
    provider_name = "Gemini"
    selected_model = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")
else:
    provider_name = None

if provider_name:
    st.markdown(
        f'<span class="status-chip">{provider_name} selected · {selected_model}</span>',
        unsafe_allow_html=True,
    )
else:
    st.markdown('<span class="status-chip">Demo Mode - Local Analysis</span>',
                unsafe_allow_html=True)

curriculum_ready = bool(st.session_state.curriculum_text)
industry_ready = bool(st.session_state.industry_text)
st.write("")
c1, c2 = st.columns(2)
with c1:
    st.metric("Curriculum evidence", "Ready" if curriculum_ready else "Missing")
with c2:
    st.metric("Industry evidence", "Ready" if industry_ready else "Missing")

if st.button("Run complete analysis", width="stretch",
             disabled=not (curriculum_ready and industry_ready)):
    if not curriculum_ready or not industry_ready:
        st.warning("Load both curriculum and industry documents first.")
    else:
        with st.spinner("Running modular agents and indexing retrieved evidence..."):
            report = AnalysisOrchestrator().run(
                st.session_state.curriculum_text,
                st.session_state.curriculum_name or "Curriculum document",
                st.session_state.industry_text,
                st.session_state.industry_name or "Industry document",
                st.session_state.industry_role,
                st.session_state.industry_domain,
            )
            st.session_state.analysis_report = report
            st.session_state.analysis_history.append({
                "Date": report["analysis_date"],
                "Role": report["industry"].get("role") or "Not specified",
                "Alignment": f"{report['gap']['alignment_score']}%",
            })

            documents = build_documents(
                st.session_state.curriculum_text,
                st.session_state.curriculum_name or "Curriculum document",
                st.session_state.industry_text,
                st.session_state.industry_name or "Industry document",
            )
            vector_store = VectorStore(VECTOR_DIR)
            vector_store.reindex(documents)
            retriever = Retriever(vector_store)
            answer, sources, ai_used = RAGPipeline(retriever).generate(
                "Identify curriculum and industry skill evidence and grounded recommendations",
                report["gap"],
            )
            st.session_state.rag_answer = answer
            st.session_state.rag_sources = sources
            st.session_state.ai_used = ai_used
        st.success("Analysis complete.")

report = st.session_state.analysis_report
if report:
    gap = report["gap"]
    st.write("")
    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Matched", len(gap["matched"]))
    k2.metric("Missing", len(gap["missing"]))
    k3.metric("Partial", len(gap["partial"]))
    k4.metric("Alignment", f"{gap['alignment_score']:.1f}%")

    tab1, tab2, tab3, tab4 = st.tabs(
        ["Comparison", "Missing", "Partial and outdated", "RAG evidence"]
    )
    with tab1:
        rows = [
            {"Skill": item["skill"], "Academic": item["academic"],
             "Status": "Matched", "Score": item["score"]}
            for item in gap["matched"]
        ]
        rows += [
            {"Skill": item["skill"], "Academic": item["academic"],
             "Status": "Missing", "Score": item["score"]}
            for item in gap["missing"]
        ]
        rows += [
            {"Skill": item["skill"], "Academic": item["academic"],
             "Status": "Partial", "Score": item["score"]}
            for item in gap["partial"]
        ]
        st.dataframe(pd.DataFrame(rows), width="stretch", hide_index=True)

    with tab2:
        if gap["missing"]:
            for item in gap["missing"]:
                st.markdown(
                    f'<div class="panel-card"><b>{item["skill"]}</b>'
                    '<br><span style="color:#9da9c7;">Industry demand without matching curriculum evidence</span>'
                    '<br><span style="color:#ff8798;">Recommendation: add practical learning outcomes.</span></div>',
                    unsafe_allow_html=True,
                )
                st.write("")
        else:
            st.success("No missing skills were identified.")

    with tab3:
        st.markdown("### Partially covered")
        st.write(", ".join(item["skill"] for item in gap["partial"]) or "None identified")
        st.markdown("### Outdated topics")
        if gap["outdated"]:
            for item in gap["outdated"]:
                st.markdown(f"- **{item['topic']}**: {item['reason']}")
        else:
            st.write("No conservative outdated-topic flags were identified.")

    with tab4:
        st.markdown("### Grounded RAG explanation")
        st.write(st.session_state.rag_answer)
        st.markdown("### Retrieved source references")
        sources = st.session_state.rag_sources
        if sources:
            for index, source in enumerate(sources, 1):
                with st.expander(f"{index}. {source['document_type']} - {source['source']}"):
                    st.write(source["text"])
        else:
            st.caption("No source chunks were retrieved.")
