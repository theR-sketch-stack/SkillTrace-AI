def load_uploaded_text(uploaded_file):
    if uploaded_file is None:
        return ""
    name = uploaded_file.name.lower()
    if name.endswith(".txt"):
        return uploaded_file.getvalue().decode("utf-8", errors="replace")
    if name.endswith(".pdf"):
        from utils.pdf_reader import read_pdf
        return read_pdf(uploaded_file)
    if name.endswith(".docx"):
        from utils.docx_reader import read_docx
        return read_docx(uploaded_file)
    raise ValueError("Unsupported file type. Upload PDF, DOCX, or TXT.")

