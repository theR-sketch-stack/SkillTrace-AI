import io
import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle


def build_excel(report):
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        gap_rows = []
        for category in ("matched", "missing", "partial"):
            for item in report["gap"].get(category, []):
                gap_rows.append({"Category": category.title(),
                                 "Skill": item["skill"],
                                 "Academic Coverage": item["academic"],
                                 "Industry Demand": "Identified"})
        pd.DataFrame(gap_rows).to_excel(writer, sheet_name="Skill Gap", index=False)
        pd.DataFrame(report["recommendations"]).to_excel(
            writer, sheet_name="Recommendations", index=False
        )
        pd.DataFrame([{
            "Project": report["title"],
            "Analysis Date": report["analysis_date"],
            "Alignment Score": report["gap"]["alignment_score"],
        }]).to_excel(writer, sheet_name="Summary", index=False)
    return output.getvalue()


def build_csv(report):
    rows = []
    for category in ("matched", "missing", "partial"):
        for item in report["gap"].get(category, []):
            rows.append({"category": category, "skill": item["skill"],
                         "academic_coverage": item["academic"]})
    for recommendation in report["recommendations"]:
        rows.append({"category": "recommendation",
                     "skill": recommendation["industry_skill"],
                     "academic_coverage": recommendation["topic"]})
    return pd.DataFrame(rows).to_csv(index=False).encode("utf-8")


def build_pdf(report):
    output = io.BytesIO()
    document = SimpleDocTemplate(output, pagesize=A4)
    styles = getSampleStyleSheet()
    story = [
        Paragraph(report["title"], styles["Title"]),
        Paragraph(f"Analysis date: {report['analysis_date']}", styles["Normal"]),
        Spacer(1, 12),
        Paragraph(
            f"<b>Overall alignment:</b> {report['gap']['alignment_score']}%",
            styles["Heading2"],
        ),
        Paragraph(
            f"Curriculum source: {report['curriculum']['name']}<br/>"
            f"Industry source: {report['industry']['name']}<br/>"
            f"Role: {report['industry'].get('role', 'Not specified')}<br/>"
            f"Domain: {report['industry'].get('domain', 'Not specified')}",
            styles["Normal"],
        ),
        Spacer(1, 12),
    ]
    for category, heading in (
        ("matched", "Matched Skills"),
        ("missing", "Missing Skills"),
        ("partial", "Partially Covered Skills"),
    ):
        story.append(Paragraph(heading, styles["Heading2"]))
        items = [item["skill"] for item in report["gap"].get(category, [])]
        story.append(Paragraph(", ".join(items) if items else "None identified",
                               styles["Normal"]))
        story.append(Spacer(1, 8))

    story.append(Paragraph("Curriculum Improvement Recommendations",
                           styles["Heading2"]))
    table_data = [["Topic", "Status", "Priority"]]
    for recommendation in report["recommendations"]:
        table_data.append([
            recommendation["topic"],
            recommendation["status"],
            recommendation["priority"],
        ])
    table = Table(table_data, repeatRows=1, colWidths=[280, 90, 70])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2F67F6")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    story.append(table)
    document.build(story)
    return output.getvalue()
