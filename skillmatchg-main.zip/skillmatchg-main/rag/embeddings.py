import hashlib
import re


class Embeddings:
    def __init__(self):
        self.model = None
        try:
            from sentence_transformers import SentenceTransformer
            self.model = SentenceTransformer("all-MiniLM-L6-v2")
        except Exception:
            self.model = None

    def encode(self, texts):
        if self.model:
            return self.model.encode(texts).tolist()
        vectors = []
        for text in texts:
            tokens = re.findall(r"[a-z0-9]+", str(text).lower())
            vector = [0] * 256
            for token in tokens:
                index = int(hashlib.md5(token.encode()).hexdigest(), 16) % 256
                vector[index] += 1
            norm = sum(value * value for value in vector) ** 0.5 or 1
            vectors.append([value / norm for value in vector])
        return vectors

