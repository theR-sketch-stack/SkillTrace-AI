import re


def split_text(text, chunk_size=700, overlap=100):
    text = re.sub(r"\n{3,}", "\n\n", text or "").strip()
    if not text:
        return []
    chunks = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        piece = text[start:end]
        chunks.append(piece)
        if end >= len(text):
            break
        start = end - overlap
    return chunks

