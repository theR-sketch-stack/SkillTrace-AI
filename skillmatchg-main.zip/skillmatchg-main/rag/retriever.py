class Retriever:
    def __init__(self, vector_store):
        self.vector_store = vector_store

    def retrieve(self, query, n_results=5):
        return self.vector_store.search(query, n_results=n_results)

