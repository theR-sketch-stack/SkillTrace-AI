import json
from pathlib import Path

import numpy as np

from rag.embeddings import Embeddings


class VectorStore:
    def __init__(self, persist_directory):
        self.persist_directory = Path(persist_directory)
        self.persist_directory.mkdir(parents=True, exist_ok=True)
        self.data_file = self.persist_directory / "knowledge_index.json"
        self.embeddings = Embeddings()
        self.records = self._load()
        self.chroma = None
        try:
            import chromadb
            self.chroma = chromadb.PersistentClient(path=str(self.persist_directory))
            self.collection = self.chroma.get_or_create_collection("skillmatch")
        except Exception:
            self.collection = None

    def _load(self):
        if self.data_file.exists():
            try:
                payload = json.loads(self.data_file.read_text(encoding="utf-8"))
                loaded = []
                for item in payload:
                    record = item.get("record", {})
                    record["embedding"] = item.get("embedding", [])
                    loaded.append(record)
                return loaded
            except Exception:
                return []
        return []

    def reset(self):
        if self.chroma and self.collection:
            try:
                self.chroma.delete_collection("skillmatch")
                self.collection = self.chroma.get_or_create_collection("skillmatch")
            except Exception:
                pass
        self.records = []
        if self.data_file.exists():
            self.data_file.unlink()

    def reindex(self, documents):
        self.reset()
        for document in documents:
            chunks = document["chunks"]
            vectors = self.embeddings.encode(chunks)
            for index, (chunk, vector) in enumerate(zip(chunks, vectors)):
                record = {
                    "text": chunk,
                    "source": document["source"],
                    "document_type": document["document_type"],
                    "chunk": index,
                    "embedding": vector,
                }
                self.records.append(record)
                if self.collection:
                    try:
                        self.collection.add(
                            ids=[f"{document['source']}-{index}-{len(self.records)}"],
                            embeddings=[vector],
                            documents=[chunk],
                            metadatas=[{"source": document["source"],
                                        "document_type": document["document_type"],
                                        "chunk": str(index)}],
                        )
                    except Exception:
                        pass
        serializable = [{k: v for k, v in record.items() if k != "embedding"} for record in self.records]
        fallback_vectors = [record["embedding"] for record in self.records]
        payload = [{"record": record, "embedding": vector}
                   for record, vector in zip(serializable, fallback_vectors)]
        self.data_file.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")

    def search(self, query, n_results=5):
        query_vector = np.array(self.embeddings.encode([query])[0])
        if self.collection:
            try:
                result = self.collection.query(
                    query_embeddings=[query_vector.tolist()],
                    n_results=min(n_results, max(1, len(self.records))),
                )
                documents = result.get("documents", [[]])[0]
                metadatas = result.get("metadatas", [[]])[0]
                return [{"text": text,
                         "source": meta.get("source", "Unknown"),
                         "document_type": meta.get("document_type", "Document")}
                        for text, meta in zip(documents, metadatas)]
            except Exception:
                pass

        scored = []
        for record in self.records:
            vector = np.array(record["embedding"])
            denominator = np.linalg.norm(vector) * np.linalg.norm(query_vector)
            score = float(np.dot(vector, query_vector) / denominator) if denominator else 0.0
            scored.append((score, record))
        scored.sort(key=lambda item: item[0], reverse=True)
        return [{"text": record["text"], "source": record["source"],
                 "document_type": record["document_type"]}
                for _, record in scored[:n_results]]
