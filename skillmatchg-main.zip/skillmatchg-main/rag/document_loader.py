from rag.text_splitter import split_text


def build_documents(curriculum_text, curriculum_name, industry_text, industry_name):
    documents = []
    if curriculum_text:
        documents.append({"chunks": split_text(curriculum_text),
                          "source": curriculum_name,
                          "document_type": "Curriculum"})
    if industry_text:
        documents.append({"chunks": split_text(industry_text),
                          "source": industry_name,
                          "document_type": "Industry Requirement"})
    return documents

