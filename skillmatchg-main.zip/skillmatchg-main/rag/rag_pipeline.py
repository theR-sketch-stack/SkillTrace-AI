import json
import os
from urllib.request import Request, urlopen


class RAGPipeline:
    def __init__(self, retriever):
        self.retriever = retriever

    @staticmethod
    def _local_answer(gap_result, provider_error=None):
        matched = ", ".join(item["skill"] for item in gap_result["matched"]) or "None identified"
        missing = ", ".join(item["skill"] for item in gap_result["missing"]) or "None identified"
        partial = ", ".join(item["skill"] for item in gap_result["partial"]) or "None identified"
        answer = (
            "Local evidence-based analysis.\n\n"
            f"Matched skills: {matched}.\n"
            f"Industry skills not found in curriculum evidence: {missing}.\n"
            f"Partially covered skills: {partial}.\n\n"
            "These findings use the supplied documents, retrieved source chunks and the "
            "transparent local skill matcher. Verify source documents before making decisions."
        )
        if provider_error:
            answer = f"{answer}\n\nProvider status: {provider_error}"
        return answer

    @staticmethod
    def _nexus_answer(query, gap_result, context):
        base_url = os.getenv(
            "NEXUS_API_BASE_URL", "https://nexusapi.navigatelabs.ai"
        ).rstrip("/")
        endpoint = (
            f"{base_url}/chat/completions"
            if base_url.endswith("/v1")
            else f"{base_url}/v1/chat/completions"
        )
        prompt = (
            "Using only the retrieved context, explain the curriculum skill gap. "
            "Separate source-based findings from recommendations. Do not add "
            "unsupported curriculum facts.\n\n"
            f"Question: {query}\n\n"
            f"Analysis summary: {gap_result}\n\nRetrieved context:\n{context}"
        )
        payload = json.dumps({
            "model": os.getenv("NEXUS_MODEL", "gpt-4.1-nano"),
            "messages": [{"role": "user", "content": prompt}],
        }).encode("utf-8")
        request = Request(
            endpoint,
            data=payload,
            headers={
                "Authorization": f"Bearer {os.environ['NEXUS_API_KEY']}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        with urlopen(request, timeout=60) as response:
            result = json.loads(response.read().decode("utf-8"))
        choices = result.get("choices", [])
        if not choices:
            return ""
        content = choices[0].get("message", {}).get("content", "")
        return content.strip() if isinstance(content, str) else ""

    def generate(self, query, gap_result):
        sources = self.retriever.retrieve(query, n_results=5)
        context = "\n\n".join(
            f"[{source['document_type']}: {source['source']}]\n{source['text']}"
            for source in sources
        )
        nexus_api_key = os.getenv("NEXUS_API_KEY", "")
        if nexus_api_key:
            try:
                answer = self._nexus_answer(query, gap_result, context)
                if not answer:
                    return self._local_answer(
                        gap_result, "Nexus returned an empty response."
                    ), sources, False
                return answer, sources, True
            except Exception as exc:
                return self._local_answer(
                    gap_result, f"Nexus request failed: {exc}"
                ), sources, False

        api_key = os.getenv("GEMINI_API_KEY", "")
        if not api_key:
            return self._local_answer(gap_result), sources, False

        try:
            from google import genai

            model = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")
            client = genai.Client(api_key=api_key)
            prompt = (
                "Using only the retrieved context, explain the curriculum skill gap. "
                "Separate source-based findings from recommendations. Do not add "
                "unsupported curriculum facts.\n\n"
                f"Analysis summary: {gap_result}\n\nRetrieved context:\n{context}"
            )
            response = client.models.generate_content(
                model=model,
                contents=prompt,
                config={"max_output_tokens": 700, "temperature": 0.2},
            )
            if not response.text:
                return self._local_answer(gap_result, "Gemini returned an empty response."), sources, False
            return response.text, sources, True
        except Exception as exc:
            return self._local_answer(gap_result, f"Gemini request failed: {exc}"), sources, False
