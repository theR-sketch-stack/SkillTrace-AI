from core.skill_extractor import extract_skills, extract_subjects


class CurriculumAnalysisAgent:
    def run(self, text):
        return {
            "subjects": extract_subjects(text),
            "skills": extract_skills(text),
            "text": text,
            "learning_outcomes": [
                line.strip() for line in text.splitlines()
                if "outcome" in line.lower() or "student should" in line.lower()
            ][:20],
        }
