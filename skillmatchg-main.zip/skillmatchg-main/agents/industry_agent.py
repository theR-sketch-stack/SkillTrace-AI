from core.skill_extractor import extract_skills


class IndustryAnalysisAgent:
    def run(self, text, role="", domain=""):
        return {
            "role": role,
            "domain": domain,
            "skills": extract_skills(text),
            "text": text,
            "requirements": [
                line.strip() for line in text.splitlines()
                if len(line.strip()) > 15
            ][:30],
        }
