import datetime


class ReportGenerationAgent:
    def run(self, curriculum, industry, gap_result, recommendations):
        return {
            "title": "SkillMatch AI Curriculum and Industry Skill Gap Report",
            "analysis_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
            "curriculum": curriculum,
            "industry": industry,
            "gap": gap_result,
            "recommendations": recommendations,
        }
