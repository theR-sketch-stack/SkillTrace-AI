from core.recommendation_engine import build_recommendations


class CurriculumRecommendationAgent:
    def run(self, gap_result):
        return build_recommendations(gap_result)
