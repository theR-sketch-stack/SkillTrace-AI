from agents.curriculum_agent import CurriculumAnalysisAgent
from agents.industry_agent import IndustryAnalysisAgent
from agents.skill_gap_agent import SkillGapDetectionAgent
from agents.recommendation_agent import CurriculumRecommendationAgent
from agents.report_agent import ReportGenerationAgent


class AnalysisOrchestrator:
    def __init__(self):
        self.curriculum_agent = CurriculumAnalysisAgent()
        self.industry_agent = IndustryAnalysisAgent()
        self.gap_agent = SkillGapDetectionAgent()
        self.recommendation_agent = CurriculumRecommendationAgent()
        self.report_agent = ReportGenerationAgent()

    def run(self, curriculum_text, curriculum_name, industry_text,
            industry_name, role="", domain=""):
        curriculum = self.curriculum_agent.run(curriculum_text)
        curriculum["name"] = curriculum_name
        industry = self.industry_agent.run(industry_text, role, domain)
        industry["name"] = industry_name
        gap = self.gap_agent.run(curriculum, industry)
        recommendations = self.recommendation_agent.run(gap)
        report = self.report_agent.run(curriculum, industry, gap, recommendations)
        return report
