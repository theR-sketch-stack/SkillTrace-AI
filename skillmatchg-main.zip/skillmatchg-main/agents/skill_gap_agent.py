from core.gap_analyzer import analyze_gap
from core.alignment_calculator import calculate_alignment


class SkillGapDetectionAgent:
    def run(self, curriculum, industry):
        result = analyze_gap(
            curriculum["skills"],
            industry["skills"],
            curriculum["text"],
            industry["text"],
        )
        result["alignment_score"] = calculate_alignment(result)
        return result
