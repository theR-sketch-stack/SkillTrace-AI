from rag.text_splitter import split_text
from utils.helpers import load_uploaded_text


def test_split_text_empty():
    assert split_text("") == []


def test_split_text_chunks():
    chunks = split_text("A" * 1600, chunk_size=700, overlap=100)
    assert len(chunks) >= 2


def test_invalid_upload_type():
    class Dummy:
        name = "document.bin"

    try:
        load_uploaded_text(Dummy())
    except ValueError as exc:
        assert "Unsupported" in str(exc)
    else:
        raise AssertionError("Unsupported file types should raise ValueError")
