from core.gap_analyzer import analyze_gap
from core.alignment_calculator import calculate_alignment


def test_missing_skill_identification():
    result = analyze_gap(["Python"], ["Python", "Docker"], "Python", "Python Docker")
    assert any(item["skill"] == "Docker" for item in result["missing"])


def test_alignment_calculation():
    result = {
        "matched": [{"skill": "Python"}],
        "partial": [{"skill": "SQL"}],
        "missing": [{"skill": "Docker"}],
    }
    assert calculate_alignment(result) == 50.0
