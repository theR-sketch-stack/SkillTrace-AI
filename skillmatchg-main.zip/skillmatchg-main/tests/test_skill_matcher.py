from core.skill_matcher import match_skills, semantic_match_score


def test_semantic_match_exact():
    assert semantic_match_score("Python", "Python") == 1.0


def test_match_skills_missing():
    matches, unmatched_academic, unmatched_industry = match_skills(
        ["Python", "SQL"], ["Python", "Docker"]
    )
    assert "Docker" in unmatched_industry
    assert "SQL" in unmatched_academic
