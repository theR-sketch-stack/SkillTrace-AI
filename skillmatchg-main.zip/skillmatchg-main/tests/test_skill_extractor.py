from core.skill_extractor import extract_skills, extract_subjects


def test_extract_skills():
    text = "Learn Python, SQL, Docker and REST APIs."
    skills = extract_skills(text)
    assert "Python" in skills
    assert "SQL" in skills
    assert "Docker" in skills


def test_extract_skills_empty_text():
    assert extract_skills("") == []


def test_extract_subjects():
    text = "Subject: Database Systems\nUnit: Machine Learning"
    subjects = extract_subjects(text)
    assert subjects
