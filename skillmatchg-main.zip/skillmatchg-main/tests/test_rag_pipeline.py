import json
import os
import sys
import types

from rag.rag_pipeline import RAGPipeline


class FakeRetriever:
    def retrieve(self, query, n_results=5):
        return [{"text": "The curriculum covers Python.",
                 "source": "curriculum.txt",
                 "document_type": "Curriculum"}]


def test_local_grounded_answer_without_provider(monkeypatch):
    monkeypatch.delenv("NEXUS_API_KEY", raising=False)
    monkeypatch.delenv("NEXUS_API_BASE_URL", raising=False)
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    result = {
        "matched": [{"skill": "Python"}],
        "missing": [{"skill": "Docker"}],
        "partial": [],
    }

    answer, sources, ai_used = RAGPipeline(FakeRetriever()).generate("gap", result)

    assert "Docker" in answer
    assert "Python" in answer
    assert sources[0]["source"] == "curriculum.txt"
    assert ai_used is False


def test_gemini_error_falls_back_to_grounded_answer(monkeypatch):
    monkeypatch.delenv("NEXUS_API_KEY", raising=False)
    monkeypatch.delenv("NEXUS_API_BASE_URL", raising=False)
    monkeypatch.setenv("GEMINI_API_KEY", "test-key")

    class FakeClient:
        class Models:
            @staticmethod
            def generate_content(**kwargs):
                raise RuntimeError("test Gemini failure")

        models = Models()

    fake_genai = types.SimpleNamespace(Client=lambda **kwargs: FakeClient())
    monkeypatch.setitem(sys.modules, "google.genai", fake_genai)
    monkeypatch.setitem(sys.modules, "google", types.SimpleNamespace(genai=fake_genai))
    result = {
        "matched": [{"skill": "Python"}],
        "missing": [{"skill": "Docker"}],
        "partial": [],
    }

    answer, sources, ai_used = RAGPipeline(FakeRetriever()).generate("gap", result)

    assert "Docker" in answer
    assert "Gemini request failed" in answer
    assert sources
    assert ai_used is False


def test_nexus_uses_configured_openai_compatible_endpoint(monkeypatch):
    monkeypatch.setenv("NEXUS_API_KEY", "test-nexus-key")
    monkeypatch.setenv("NEXUS_API_BASE_URL", "https://nexus.example/v1/")
    monkeypatch.setenv("NEXUS_MODEL", "gpt-test")
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    captured = {}

    class FakeResponse:
        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        @staticmethod
        def read():
            return json.dumps({
                "choices": [{"message": {"content": "Grounded Nexus answer"}}]
            }).encode("utf-8")

    def fake_urlopen(request, timeout):
        captured["url"] = request.full_url
        captured["authorization"] = request.get_header("Authorization")
        captured["payload"] = json.loads(request.data.decode("utf-8"))
        captured["timeout"] = timeout
        return FakeResponse()

    monkeypatch.setattr("rag.rag_pipeline.urlopen", fake_urlopen)
    result = {
        "matched": [{"skill": "Python"}],
        "missing": [{"skill": "Docker"}],
        "partial": [],
    }

    answer, sources, ai_used = RAGPipeline(FakeRetriever()).generate("gap", result)

    assert answer == "Grounded Nexus answer"
    assert sources[0]["source"] == "curriculum.txt"
    assert ai_used is True
    assert captured["url"] == "https://nexus.example/v1/chat/completions"
    assert captured["authorization"] == "Bearer test-nexus-key"
    assert captured["payload"]["model"] == "gpt-test"
    assert captured["timeout"] == 60


def test_nexus_error_falls_back_to_grounded_answer(monkeypatch):
    monkeypatch.setenv("NEXUS_API_KEY", "test-nexus-key")
    monkeypatch.setenv("NEXUS_API_BASE_URL", "https://nexus.example")
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)

    def fail_urlopen(request, timeout):
        raise RuntimeError("test Nexus failure")

    monkeypatch.setattr("rag.rag_pipeline.urlopen", fail_urlopen)
    result = {
        "matched": [{"skill": "Python"}],
        "missing": [{"skill": "Docker"}],
        "partial": [],
    }

    answer, sources, ai_used = RAGPipeline(FakeRetriever()).generate("gap", result)

    assert "Docker" in answer
    assert "Nexus request failed" in answer
    assert sources
    assert ai_used is False
