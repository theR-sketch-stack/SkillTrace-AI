# SkillMatch AI

SkillMatch AI is a Streamlit-based curriculum and industry skill gap analysis system.
It compares a curriculum document with industry job requirements, identifies matched,
missing, partially covered and emerging skills, generates recommendations, and produces
PDF, Excel and CSV reports.

## Features

- Premium responsive dashboard
- Sidebar light/dark appearance switch with coordinated chart and widget colors
- Curriculum PDF, DOCX and TXT upload
- Job description upload and pasted text
- Sample job descriptions
- Rule-based and semantic skill matching
- Transparent alignment score
- Modular Python AI agents
- Persistent ChromaDB vector storage with local fallback
- Sentence Transformer embeddings with deterministic local fallback
- Optional Google Gemini grounded generation
- Demo Mode without an API key
- PDF, Excel and CSV report downloads

## Architecture

```mermaid
flowchart LR
    U[Streamlit UI] --> C[Curriculum Agent]
    U --> I[Industry Agent]
    C --> O[Orchestrator]
    I --> O
    O --> G[Skill Gap Agent]
    G --> R[Recommendation Agent]
    R --> P[Report Agent]
    C --> V[Document Chunking]
    I --> V
    V --> E[Embeddings]
    E --> X[ChromaDB / Persistent Fallback]
    X --> Q[RAG Retriever]
    Q --> A[Gemini or Demo Mode]
```

## Alignment methodology

The alignment score is:

`((matched skills × 1) + (partial skills × 0.5)) / (matched + partial + missing) × 100`

It is transparent and source-limited; it is not a claim of verified national statistics.

## Installation

```powershell
cd C:\Users\user\Downloads\skillgap
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## AI provider configuration

Copy `.env.example` to `.env` and set:

```env
NEXUS_API_KEY=your_nexus_api_key_here
NEXUS_API_BASE_URL=https://nexusapi.navigatelabs.ai
NEXUS_MODEL=gpt-4.1-nano
```

Nexus uses an OpenAI-compatible chat-completions endpoint. If Nexus is not configured,
the app can use Gemini with `GEMINI_API_KEY` and `GEMINI_MODEL`. Without either provider,
the app continues in Demo Mode using local extraction, matching, retrieval and report
generation.

If a configured provider rejects a request or is unavailable, the app displays a
source-based local analysis and includes the provider error.

## Run

```powershell
streamlit run app.py
```

Open the URL printed by Streamlit. For a presentation:

0. Choose **Dark** or **Light** in the sidebar under Appearance.
1. Open Curriculum and upload a curriculum document.
2. Open Industry requirements and load a sample job description.
3. Open Skill gap analysis and run the complete analysis.
4. Review recommendations and download reports.

## Tests

```powershell
python -m pytest -q
```

## Folder structure

`app.py` is the entrypoint and `app_pages/` contains Streamlit pages. `agents/` contains
the functional orchestrated agents. `core/` contains skill extraction and gap logic.
`rag/` contains chunking, embeddings, retrieval and vector storage. `utils/` contains
document readers and report generation.
