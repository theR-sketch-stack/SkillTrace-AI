import re
import numpy as np


CANONICAL_ALIASES = {
    "artificial intelligence": ["ai", "artificial intelligence"],
    "machine learning": ["ml", "machine learning"],
    "sql": ["sql", "mysql", "postgresql", "database"],
    "rest apis": ["rest", "rest api", "restful api"],
    "cloud computing": ["cloud", "cloud computing", "aws", "azure"],
}


def normalize_skill(skill):
    value = re.sub(r"[^a-z0-9]+", " ", str(skill).lower()).strip()
    for canonical, aliases in CANONICAL_ALIASES.items():
        if value in aliases:
            return canonical
    return value


def semantic_match_score(a, b):
    """Lightweight semantic fallback based on normalized tokens."""
    left = set(normalize_skill(a).split())
    right = set(normalize_skill(b).split())
    if not left or not right:
        return 0.0
    if left == right:
        return 1.0
    overlap = len(left & right) / max(len(left | right), 1)
    return float(overlap)


def match_skills(academic_skills, industry_skills, threshold=0.55):
    matches = []
    used_industry = set()
    for academic in academic_skills:
        best_name = None
        best_score = 0.0
        for industry in industry_skills:
            score = semantic_match_score(academic, industry)
            if score > best_score:
                best_name = industry
                best_score = score
        if best_name and best_score >= threshold:
            matches.append((academic, best_name, best_score))
            used_industry.add(best_name)
    unmatched_academic = [x for x in academic_skills if not any(m[0] == x for m in matches)]
    unmatched_industry = [x for x in industry_skills if x not in used_industry]
    return matches, unmatched_academic, unmatched_industry

