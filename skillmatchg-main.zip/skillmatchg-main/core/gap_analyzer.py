from core.skill_matcher import match_skills


OUTDATED_TOPICS = [
    ("Legacy RDBMS-only SQL", "SQL", "Include modern SQL optimization, NoSQL and cloud data services."),
    ("Standalone C/C++ Curriculum", "Programming", "Add modern language ecosystems, testing and DevOps practices."),
]


def analyze_gap(academic_skills, industry_skills, academic_text="", industry_text=""):
    matches, unmatched_academic, unmatched_industry = match_skills(
        academic_skills, industry_skills
    )
    matched = [{"skill": industry, "academic": academic, "score": round(score, 2)}
               for academic, industry, score in matches]
    missing = [{"skill": skill, "academic": "None", "score": 0.0}
               for skill in unmatched_industry]

    partial = []
    lower_academic = academic_text.lower()
    lower_industry = industry_text.lower()
    for skill in unmatched_industry[:3]:
        if skill.lower() in lower_academic:
            partial.append({"skill": skill, "academic": "Mentioned only", "score": 0.45})
            missing = [item for item in missing if item["skill"] != skill]

    academic_lower = academic_text.lower()
    outdated = []
    for topic, marker, reason in OUTDATED_TOPICS:
        if marker.lower() in academic_lower and marker.lower() in industry_text.lower():
            outdated.append({
                "topic": topic,
                "reason": reason,
                "industry_skill": marker,
            })

    emerging = [
        {"skill": item["skill"], "reason": "Appears in industry demand and is not matched to curriculum."}
        for item in missing
    ]
    return {
        "matched": matched,
        "missing": missing,
        "partial": partial,
        "outdated": outdated,
        "emerging": emerging,
        "academic_skills": academic_skills,
        "industry_skills": industry_skills,
    }
