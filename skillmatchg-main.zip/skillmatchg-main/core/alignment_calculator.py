def calculate_alignment(result):
    matched = len(result.get("matched", []))
    partial = len(result.get("partial", []))
    missing = len(result.get("missing", []))
    total = matched + partial + missing
    if total == 0:
        return 0.0
    score = ((matched * 1.0) + (partial * 0.5)) / total * 100
    return round(score, 1)

