import re

SKILL_LIBRARY = [
    ("Python", ["python"]),
    ("Java", ["java"]),
    ("C++", ["c++", "cpp"]),
    ("JavaScript", ["javascript", "js"]),
    ("TypeScript", ["typescript"]),
    ("SQL", ["sql", "mysql", "postgresql", "database"]),
    ("HTML", ["html"]),
    ("CSS", ["css"]),
    ("React", ["react", "reactjs"]),
    ("Node.js", ["node.js", "nodejs"]),
    ("REST APIs", ["rest api", "restful", "rest"]),
    ("Git", ["git", "github"]),
    ("Linux", ["linux"]),
    ("Docker", ["docker"]),
    ("Kubernetes", ["kubernetes"]),
    ("AWS", ["aws", "amazon web services"]),
    ("Azure", ["azure"]),
    ("Cloud Computing", ["cloud computing", "cloud"]),
    ("Data Structures", ["data structures"]),
    ("Algorithms", ["algorithms", "algorithm"]),
    ("Object-Oriented Programming", ["object oriented", "oop"]),
    ("Operating Systems", ["operating systems"]),
    ("Computer Networks", ["computer networks", "networking"]),
    ("Software Engineering", ["software engineering"]),
    ("Machine Learning", ["machine learning", "ml"]),
    ("Deep Learning", ["deep learning"]),
    ("Artificial Intelligence", ["artificial intelligence", " ai ", "ai"]),
    ("Data Analysis", ["data analysis", "data analytics"]),
    ("Statistics", ["statistics", "statistical"]),
    ("Pandas", ["pandas"]),
    ("NumPy", ["numpy"]),
    ("Scikit-learn", ["scikit-learn", "sklearn"]),
    ("TensorFlow", ["tensorflow"]),
    ("PyTorch", ["pytorch"]),
    ("Generative AI", ["generative ai", "genai", "llm"]),
    ("Prompt Engineering", ["prompt engineering"]),
    ("NLP", ["natural language processing", "nlp"]),
    ("Tableau", ["tableau"]),
    ("Power BI", ["power bi"]),
    ("Spring Boot", ["spring boot", "spring"]),
    ("FastAPI", ["fastapi"]),
    ("Django", ["django"]),
    ("Flask", ["flask"]),
    ("Cybersecurity", ["cybersecurity", "security"]),
    ("DevOps", ["devops", "ci/cd", "ci cd"]),
]


def extract_skills(text):
    """Extract known technical skills using normalized keyword matching."""
    if not text:
        return []
    normalized = " " + re.sub(r"\s+", " ", text.lower()) + " "
    found = []
    for skill, aliases in SKILL_LIBRARY:
        if any(alias.strip() in normalized for alias in aliases):
            found.append(skill)
    return sorted(set(found))


def extract_subjects(text):
    """Extract a conservative subject/topic list from common curriculum headings."""
    if not text:
        return []
    subjects = set()
    patterns = [
        r"(?:course|subject|unit)\s*[:-]?\s*([A-Za-z][A-Za-z0-9 &+\-/]{2,70})",
        r"^\s*(Data Structures|Algorithms|Database Systems|Operating Systems|"
        r"Computer Networks|Software Engineering|Machine Learning|Artificial Intelligence"
        r"|Web Development|Cloud Computing|Cybersecurity)\b",
    ]
    for pattern in patterns:
        for match in re.finditer(pattern, text, re.I | re.M):
            value = match.group(1).strip() if match.groups() else match.group(0).strip()
            value = re.sub(r"\s+", " ", value).strip(" .:-")
            if len(value) <= 80:
                subjects.add(value)
    return sorted(subjects)

