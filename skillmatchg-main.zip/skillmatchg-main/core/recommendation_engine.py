def build_recommendations(gap_result):
    recommendations = []
    for item in gap_result["missing"]:
        skill = item["skill"]
        recommendations.append({
            "topic": f"{skill} Fundamentals and Applied Projects",
            "industry_skill": skill,
            "status": "Missing",
            "why": f"{skill} is required in the analyzed industry description but no matching curriculum coverage was found.",
            "learning_outcome": f"Students should understand {skill} concepts and complete an applied assessment.",
            "priority": "High",
            "source": "Industry and curriculum document evidence",
        })
    for item in gap_result["partial"]:
        skill = item["skill"]
        recommendations.append({
            "topic": f"Strengthen {skill} Coverage",
            "industry_skill": skill,
            "status": "Partially Covered",
            "why": f"{skill} is mentioned in curriculum evidence but lacks sufficient matching depth.",
            "learning_outcome": f"Students should demonstrate practical proficiency in {skill}.",
            "priority": "Medium",
            "source": "Curriculum and industry document evidence",
        })
    for item in gap_result["emerging"][:5]:
        skill = item["skill"]
        if not any(r["industry_skill"] == skill for r in recommendations):
            recommendations.append({
                "topic": f"Explore {skill}",
                "industry_skill": skill,
                "status": "Emerging",
                "why": item["reason"],
                "learning_outcome": f"Introduce {skill} at an awareness or fundamentals level and review annually.",
                "priority": "Low",
                "source": "Industry requirement evidence",
            })
    return recommendations

